To Run Naive Bayes (with default Ricci Data CSV):

Compile in terminal using Python3:

	python3 naiveBayesMain.py

Will print the model and classification probabilities. 

You may also upload your own data set and choose the corresponding sensitive attributes and classifications.

 